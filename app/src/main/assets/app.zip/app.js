define("app.js", function(require, module, exports, window){
"use strict";//app.js
App({});
});