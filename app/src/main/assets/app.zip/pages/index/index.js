define("pages/index/index.js", function(require, module, exports, window){
"use strict";// pages/index/index.js
Page({/**
   * 页面的初始数据
   */data:{res:'',timer:false,complete:false,fail:false,failres:''},go:function go(e){var name=e.currentTarget.dataset.page;wx.navigateTo({url:"/pages/".concat(name,"/index")});},baidu:function baidu(){var that=this;setTimeout(function(){wx.request({url:'https://baidu.com',success:function success(res){that.setData({res:res.data});},complete:function complete(res){that.setData({complete:true});},fail:function fail(res){that.setData({fail:true,failres:JSON.stringify(res)});}});that.setData({timer:true});},5000);}});
});