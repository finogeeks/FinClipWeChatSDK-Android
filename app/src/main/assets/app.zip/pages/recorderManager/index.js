define("pages/recorderManager/index.js", function(require, module, exports, window){
"use strict";//index.js
//获取应用实例
var app=getApp();Page({data:{duration:'',stop:false,tempFilePath:''},onLoad:function onLoad(){var _this=this;this.ctx=wx.getRecorderManager();var listener=['Error','FrameRecorded','InterruptionBegin','InterruptionEnd','Pause','Resume','Start'];listener.forEach(function(key){_this.ctx['on'+key](function(res){console.log('on'+key,res);});});this.ctx.onStop(function(res){var tempFilePath=res.tempFilePath;_this.setData({tempFilePath:tempFilePath});});//
},start:function start(){this.ctx.start({});},resume:function resume(){this.ctx.resume();},pause:function pause(){this.ctx.pause();},stop:function stop(){this.ctx.stop();},play:function play(){if(tempFilePath){var innerAudioContext=wx.createInnerAudioContext();innerAudioContext.src=tempFilePath;innerAudioContext.play();}}});
});