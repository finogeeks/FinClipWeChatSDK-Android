define("pages/innerAudioContext/index.js", function(require, module, exports, window){
"use strict";//index.js
//获取应用实例
var app=getApp();Page({data:{volume:1,rate:1},onLoad:function onLoad(){var innerAudioContext=wx.createInnerAudioContext();this.ctx=innerAudioContext;// innerAudioContext.playbackRate = 2.0
innerAudioContext.src='/mucis.mp3';// innerAudioContext.src = 'http://cdn.amathclass.cn/quesAudio/42fe780d-1607959109843.m4a'
var listener=['Canplay','Ended','Pause','Play','Seeked','Seeking','Stop','TimeUpdate','Waiting'];listener.forEach(function(key){innerAudioContext['on'+key](function(){console.log('on'+key);});});innerAudioContext.onError(function(res){console.log(res.errMsg);console.log(res);console.log(res.errCode);});// innerAudioContext.onWaiting((res)=>{
//   console.log(res)
//   console.log('wait')
// })
},play:function play(){this.ctx.play();// this.ctx.src = '/mucis.mp3'
// this.ctx.autoplay = true
},seek:function seek(){this.ctx.seek(60);},pause:function pause(){this.ctx.pause();},destroy:function destroy(){this.ctx.destroy();console.log(this.ctx);},stop:function stop(){this.ctx.stop();},handleVolumeChange:function handleVolumeChange(e){this.setData({volume:e.detail.value});this.ctx.volume=this.data.volume;},handleRateChange:function handleRateChange(e){this.setData({rate:e.detail.value});this.ctx.rate=this.data.rate;}});
});